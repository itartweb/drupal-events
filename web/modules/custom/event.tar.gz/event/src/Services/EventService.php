<?php

namespace Drupal\event\Services;

/**
 * Class EventService.
 */
class EventService {

  /**
   * Constructs a new EventService object.
   */
  public function __construct(){}

}
